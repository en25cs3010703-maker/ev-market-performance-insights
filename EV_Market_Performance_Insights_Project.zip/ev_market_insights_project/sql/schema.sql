CREATE TABLE ev_market_data (
    record_id INTEGER PRIMARY KEY,
    year INTEGER NOT NULL,
    manufacturer VARCHAR(80) NOT NULL,
    country VARCHAR(80) NOT NULL,
    vehicle_category VARCHAR(40) NOT NULL,
    battery_technology VARCHAR(60) NOT NULL,
    battery_capacity_kwh DECIMAL(6,2),
    driving_range_km INTEGER,
    annual_sales INTEGER,
    customer_rating DECIMAL(2,1)
);
