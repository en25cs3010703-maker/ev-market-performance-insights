-- 1. Total sales by year
SELECT year, SUM(annual_sales) AS total_sales
FROM ev_market_data
GROUP BY year
ORDER BY year;

-- 2. Manufacturer market share within the available dataset
SELECT manufacturer,
       SUM(annual_sales) AS sales,
       ROUND(100.0 * SUM(annual_sales) / (SELECT SUM(annual_sales) FROM ev_market_data), 2) AS market_share_pct
FROM ev_market_data
GROUP BY manufacturer
ORDER BY sales DESC;

-- 3. Average driving range by vehicle category
SELECT vehicle_category, ROUND(AVG(driving_range_km), 1) AS avg_range_km
FROM ev_market_data
GROUP BY vehicle_category
ORDER BY avg_range_km DESC;

-- 4. Sales by battery technology
SELECT battery_technology, SUM(annual_sales) AS total_sales
FROM ev_market_data
GROUP BY battery_technology
ORDER BY total_sales DESC;

-- 5. Average customer rating by manufacturer
SELECT manufacturer, ROUND(AVG(customer_rating), 2) AS avg_rating
FROM ev_market_data
GROUP BY manufacturer
ORDER BY avg_rating DESC;
